# Validation record

Verified in the build environment on November 8, 2026:
- Node 24.9.0 / npm 11.6.0.
- `npm run build`: TypeScript and Vite production build pass.
- `npm test`: six finance tests pass.
- Browser: Explore renders with seven matching activity pins/cards and $87.50 available.
- Browser: Weekend Crew dinner invitation shows $45 all-in and $42.50 after accepting.
- Browser: cheaper options show coffee $10, campus movie $0, and noodles $18 with estimated differences.
- Browser: noodle alternative prefills plan inputs; plan creation opens checkpoint; accepting reserves $18.
- Browser: Budget shows $69.50 available / $45 spent / $45.50 committed after acceptance.
- Browser: completing noodles at actual $16 updates to $71.50 available / $61 spent / $27.50 committed.
- Browser reload preserves $71.50 in the Explore budget ribbon.

Not verified on a physical iPhone or Xcode Simulator. Phone instructions describe how to run the responsive web version; no native binary is delivered.
- Responsive browser viewport checked at 390 × 844 and 1440 × 1000; phone preview saved alongside the source package.
- Browser: maximum-price slider at $20 leaves five matching activities; free-only leaves two.
- Browser: all four budget wizard steps complete; $1,000 received less protected priorities shows $200 discretionary, and saving a $160 allocation preserves the existing ledger.
- Browser: Insights renders fictional chart, local action counts, diary, and evaluation design.
- Browser: invitation code PACT-ART joins the fictional Art Club and switches the current Circle.
- Reset restores the original $87.50 seed state for presentation.
