export const money = n => new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:2}).format(n);
export const cents = n => Math.round((Number(n)||0)*100)/100;
export const totalCost = p => cents(p.base + p.fees + p.travel + p.shared / Math.max(1,p.people));
export function ledger(budget, expenses, plans){const spent=cents(expenses.reduce((s,e)=>s+e.amount,0));const committed=cents(plans.filter(p=>p.status==='going').reduce((s,p)=>s+totalCost(p),0));return {spent,committed,available:cents(budget-spent-committed)};}
export const monthlyFunds = (amount, frequency) => cents(amount * ({weekly:52/12,biweekly:26/12,semimonthly:2,monthly:1,irregular:1}[frequency]||1));
