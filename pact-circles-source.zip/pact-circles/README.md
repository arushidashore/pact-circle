# PACT Circles
**Your social life, mapped to your budget.** FINNOVATION 2026 pitch prototype.

A working React + TypeScript + Vite application with a responsive phone interface, desktop sidebar, fictional campus map, local persistence, and no accounts, backend, API keys, banking, analytics, or location permissions. All runtime assets are bundled: the prototype makes no external requests once served. Emoji rendering varies by device.

## Start in VS Code — step by step
1. Install Node.js 22 LTS or later from https://nodejs.org and VS Code from https://code.visualstudio.com. Node 24 was used to verify this project.
2. Unzip `pact-circles-source.zip` to a normal folder you can edit.
3. In VS Code select **File → Open Folder**, then select the extracted `pact-circles` folder (the one containing `package.json`).
4. Select **Terminal → New Terminal**. Check `node -v` and `npm -v`. If either is missing, restart VS Code after installing Node.
5. Run:
   ```sh
   npm ci
   npm run dev
   ```
6. Open the **Local** URL printed in the terminal, normally http://localhost:5173. Leave the terminal running while you demo. Stop with Control+C.
7. To show a phone layout in Chrome: open Developer Tools, toggle the device toolbar, select an iPhone preset or 390 × 844, then reload. Narrowing the browser also works. The app switches to a five-tab bottom bar below 761 px.

No environment file or API key is required. Internet is needed for the initial dependency installation; the running app uses no remote resources. A built `dist` folder is included for convenience, but `npm run build` will reproduce it.

## What actually works
- **Explore:** illustrated fictional map with clickable all-in price pins, searchable activity cards, save/unsave, saved-only view, category, price slider, free-only, walking/transit, travel time, demo availability, group capacity, personal available budget, and public Circle cap filters. Cards and pins filter together. Empty results have a clear message. Detail cards show cost breakdowns and budget effects.
- **Circles:** switch groups, create a local group, display/copy its demo invite code, join a seeded Art Club using `PACT-ART`, change a public outing cap, inspect member names and plan RSVPs. Other members are fictional, not connected users.
- **Create:** name/date/Circle, food/activity, tax/tip, travel, a group shared cost and split headcount. Per-person estimate updates immediately. Save a plan, then make your own RSVP at the private checkpoint. Other members' responses remain seeded; no real notifications or invitations are sent.
- **Decision checkpoint:** before/after available funds, intentional acceptance, private decline, defer for later, and cheaper activity suggestions under the plan's Circle public cap. Alternatives prefill a new plan. The original invitation stays unchanged until you decline/defer it. Estimated differences are not verified savings.
- **Budget:** four-step setup covering funds/frequency, essentials, protected savings/buffer, and social allocation. Direct-limit mode supports students who already know their allowance. Existing spending stays intact when the budget changes. Manual expense entry/removal; commitments reserve money, cancellation releases it, completion replaces it with actual spend. Negative available funds remain visible.
- **Insights:** clearly labeled fictional estimate/actual chart, counts from your own local session, a saved confidence/participation diary, and the proposed pilot evaluation design. No claims of observed impact.
- **Persistence:** budget, expenses, plans, circles, saved activities, diary, and session events use localStorage. A reload retains them. Filters, active tab, and unfinished drafts reset. Export local JSON or reset to the original seed using footer buttons.

## Three-minute pitch walkthrough
Start fresh with **Reset demo** in the footer. The demo clock is fixed to November 8, 2026 so seeded plans remain coherent on future presentation dates.

1. **Explore:** “Good plans should include everyone.” Show **$87.50 available**. Open Filters, set maximum cost to **$20**; observe that the $45 dinner and $22 bowling disappear from both map and cards. Open the $18 noodle listing to show tax/tip and travel.
2. **Circles:** open **Weekend Crew → Review invitation** for Dinner at Saffron Table. “The meal isn't the whole cost.” The checkpoint shows **$45 all-in**, **$87.50 before**, **$42.50 after**.
3. Select **Find a different way to hang out**, then **Little Bowl ($18)**. “Stay social, spend differently.” This drafts an alternative without disclosing anyone's finances or changing the original invitation.
4. **Create plan & review → Accept intentionally & reserve $18**. Your RSVP becomes going; available becomes **$69.50**, committed **$45.50**.
5. **Budget → Log actual cost** for the noodle plan, enter **$16**, complete. Available becomes **$71.50**, spent **$61**, committed **$27.50**. “We replace the estimate rather than counting it twice.”
6. Show **Build my budget**: default received $1,000 minus $650 essentials, $100 savings, $50 buffer leaves $200 discretionary; choose a $160 social allocation. Or use direct-limit mode.
7. **Insights:** distinguish fictional charts from local demo events. Explain the proposed randomized pilot and its measures of confidence and social connection alongside spending. Close: “We measure better decisions, not just more downloads.”

Optional interactions: join `PACT-ART`, create a Circle, copy an invitation code, save an activity, log an expense, cancel pottery to release $27.50, refresh to show persistence. Reset before the next judge.

## Demo on an actual iPhone
1. Run `npm run dev` on your computer. The server listens on your local network for the phone demonstration.
2. Put your computer and iPhone on the same trusted Wi-Fi. Open the **Network** URL Vite prints in iPhone Safari, such as `http://192.168.1.20:5173`. The exact address depends on your network; `localhost` on the phone refers to the phone itself.
3. Keep your computer awake and the server running. If your firewall asks, allow the local development server on the trusted network. Guest Wi-Fi may block device-to-device access; use the desktop phone emulator if needed.
4. The phone keeps its own independent local demo state. Nothing synchronizes between devices. Clipboard copying may be unavailable on an HTTP network page; the code remains selectable. Plan creation works without secure-context UUID support.

**Xcode is optional.** This is a web project, not a native Swift project: do not open `src` as an Xcode application. If you already have Xcode and an installed iOS Simulator, launch the simulator, open Safari, and visit the computer's reachable development URL. A native wrapper/App Store build is outside this prototype. VS Code and browser emulation are the shortest demo path.

## Verify and build
```sh
npm test
npm run build
npm run preview
```
Tests cover the seed ledger, accepted-only commitments, reconciliation without double counting, cancellation, cost splitting, negative balances, and monthly income conversion. The production command type-checks TypeScript and produces `dist/`. Serve that folder over HTTP; opening `dist/index.html` as `file://` does not load module assets reliably. `npm run preview` serves it locally and prints its URL (normally port 4173).

## Money rules
- `available = monthly social allocation − actual expenses − accepted upcoming commitments`.
- `your plan cost = activity + tax/tip + travel + shared group cost ÷ planned participants`, rounded to cents.
- Invited, deferred, declined, cancelled, and completed plans do not reserve funds. Each accepted plan reserves once, regardless of RSVP count.
- Completion records actual spending and ends the reservation in one state update. Cancellation releases the full unpaid estimate. For a paid nonrefundable amount, log it separately as an expense before cancelling; payment/deposit tracking is not implemented.
- Accepted shared costs use the organizer's explicit planned headcount, not the live RSVP count. There is no automatic repricing or plan editing; cancel and create a revised plan if assumptions change.
- Regular weekly/biweekly amounts use 52/12 and 26/12 monthly averages; twice-monthly uses ×2. Irregular funds use the entered received amount only. Future income isn't forecast.
- Full setup prevents allocation beyond funds remaining after priorities; direct mode uses the user's chosen monthly social amount. A lower budget can expose a shortfall against existing commitments.

## Privacy and demo boundaries
The map is custom SVG artwork with fictional coordinates; it is not real mapping, routing, or live tracking. Event availability is seeded (Today / This weekend / Next 7 days relative to the demo week). Walking/transit times and all prices are examples, not verified listings. No venue bookings are made.

This is a single-user local demonstration of a multi-user product. Invite codes, RSVPs of fictional friends, and public caps communicate the intended experience. Cross-device membership, authentication, temporary friend location, automated reminders, real anonymous matching, native push, payments, rollover, and bank integration are not implemented.

Local storage is not encrypted and is readable by people using the same browser profile. Use fictional data only, especially on a shared pitch computer. Reset clears app state; exported JSON files remain wherever you save them. Storage is origin-specific (a different port/browser/device has a different dataset). A visible warning appears if browser storage cannot be used.

The prototype intentionally does not implement anonymous financial preference aggregation: the specification's minimum-four-distinct-members privacy safeguard requires a real backend and participant identity controls. Public caps are explicit and voluntary, not inferred from a member's private budget.

## Evidence of impact
The product hypothesis is intentional discretionary spending under social pressure. A credible future pilot would pre-specify outcomes and analyze randomized friend-circle assignments, accounting for clustering and missing diaries. Both groups receive the same workshop and independent measures. Suggested primary outcome: budget-consistent decisions in self-identified high-pressure opportunities. Secondary outcomes: unplanned spend, estimate accuracy, decision confidence, and social participation. Sample size and detectable effect require a prospective power calculation. The 200-student/40-circle design and 15-point target shown here are proposals, not findings. Chart values and action counts are not causal evidence.

## Project structure
- `src/main.tsx`: interactive tabs, forms, dialogs and local state.
- `src/data.ts`: typed fictional activities, plans, circles and seed state.
- `src/finance.mjs`: shared arithmetic used by the UI and tests.
- `src/style.css`: responsive visual system, mobile navigation and dialogs.
- `tests/finance.test.mjs`: Node built-in test runner; no test service required.
- `package-lock.json`: reproducible dependency versions.

## Troubleshooting
- **Blank page:** use the development/preview URL rather than opening a source HTML file directly. Run `npm ci` and check the terminal for errors.
- **Port already used:** use Vite's printed alternative URL, or `npm run dev -- --port 5174`.
- **Phone can't connect:** confirm same Wi-Fi, correct Network URL, firewall, and no guest isolation.
- **Old demo values:** use Reset demo. Browser storage intentionally retains changes across reloads.
- **Install fails:** check internet access and `node -v`, then rerun `npm ci`.
